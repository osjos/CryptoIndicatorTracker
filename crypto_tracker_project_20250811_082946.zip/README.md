# Crypto Market Events Tracker

## Project Overview
This is a comprehensive crypto market analysis tool that combines traditional finance indicators with Bitcoin-specific metrics to help identify market cycle positions.

## Key Features
- Real-time data updates daily at 6 AM Stockholm time
- 5 different crypto market indicators:
  1. MAG7 vs Bitcoin Index
  2. Pi Cycle Top Indicator  
  3. Coinbase App Store Ranking
  4. CBBI Score Integration
  5. Bitcoin Halving Cycle Analysis
- Interactive Plotly visualizations
- SQLite database for data persistence
- Streamlit web interface
- Deployed on Replit with autoscale

## Files Structure
- app.py: Main Streamlit application
- data_manager.py: Database management
- scheduler.py: Background task scheduling
- utils/: Data fetching modules for each indicator
- pages/: Additional Streamlit pages
- crypto_tracker.db: SQLite database

## Installation
1. Install dependencies: pip install -r requirements.txt (or use pyproject.toml)
2. Run: streamlit run app.py

## Deployment
Configured for Replit deployment with .replit configuration file.
