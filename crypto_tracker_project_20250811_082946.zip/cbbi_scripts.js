// Script 1

        let _paq = window._paq = window._paq || [];
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        (function () {
            let u = "https://matomo.monicz.dev/";
            _paq.push(['setTrackerUrl', u + 'matomo.php']);
            _paq.push(['setSiteId', '3']);
            let d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
            g.async = true;
            g.src = u + 'matomo.js';
            s.parentNode.insertBefore(g, s);
        })();
    

// Script 2
// No inline content


// Script 3
// No inline content


// Script 4
// No inline content


// Script 5
// No inline content


// Script 6
// No inline content


// Script 7
// No inline content


// Script 8
// No inline content


// Script 9
// No inline content


